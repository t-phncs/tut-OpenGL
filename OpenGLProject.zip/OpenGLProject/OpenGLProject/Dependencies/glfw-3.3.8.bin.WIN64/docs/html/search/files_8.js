var searchData=
[
  ['window_2edox_0',['window.dox',['../window_8dox.html',1,'']]]
];
