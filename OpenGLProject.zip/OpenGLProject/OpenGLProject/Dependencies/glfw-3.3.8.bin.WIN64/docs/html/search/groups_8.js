var searchData=
[
  ['standard_20cursor_20shapes_0',['Standard cursor shapes',['../group__shapes.html',1,'']]]
];
